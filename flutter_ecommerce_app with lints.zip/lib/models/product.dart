class Product {
  final String id;
  String title;
  String description;

  Product({required this.id, required this.title, required this.description});
}
