import 'package:flutter/material.dart';
import '../models/product.dart';
import '../main.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Product> _products = [];

  void _navigateToAddProduct() async {
    final result = await Navigator.pushNamed(context, MyApp.productFormRoute);
    if (result is Product) {
      setState(() {
        _products.add(result);
      });
    }
  }

  void _navigateToDetail(Product product) {
    Navigator.pushNamed(context, MyApp.productDetailRoute, arguments: product);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Products')),
      body: ListView.builder(
        itemCount: _products.length,
        itemBuilder: (ctx, i) {
          final product = _products[i];
          return ListTile(
            title: Text(product.title),
            subtitle: Text(product.description),
            onTap: () => _navigateToDetail(product),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddProduct,
        child: Icon(Icons.add),
      ),
    );
  }
}
