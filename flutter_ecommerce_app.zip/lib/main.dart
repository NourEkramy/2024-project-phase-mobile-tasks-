import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/product_detail_screen.dart';
import 'screens/product_form_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static const String homeRoute = '/';
  static const String productDetailRoute = '/product-detail';
  static const String productFormRoute = '/product-form';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ecommerce App',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: homeRoute,
      routes: {
        homeRoute: (context) => HomeScreen(),
        productDetailRoute: (context) => ProductDetailScreen(),
        productFormRoute: (context) => ProductFormScreen(),
      },
    );
  }
}
