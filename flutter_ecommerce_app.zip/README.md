# Flutter Ecommerce App

## Overview
This Flutter app is a basic ecommerce product management system. It allows users to:
- View a list of products
- Add a new product
- View product details

## Features
- Named routes and smooth navigation
- Data passing between screens
- Back button handling

## How to Run
1. Make sure Flutter is installed
2. Run `flutter pub get`
3. Run `flutter run`
